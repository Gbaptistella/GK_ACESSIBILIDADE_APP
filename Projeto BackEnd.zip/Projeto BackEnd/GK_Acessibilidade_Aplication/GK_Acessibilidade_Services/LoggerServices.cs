﻿using GK_Acessibilidade_Data.Interfaces;
using GK_Acessibilidade_Domain.Entity.Empresas;
using GK_Acessibilidade_Domain.Entity.Logger;
using GK_Acessibilidade_Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Services
{
    public class LoggerServices : ILoggerServices
    {
        private readonly ILoggerRepository _loggerRepository;
        public LoggerServices(ILoggerRepository loggerRepository)
        {
            _loggerRepository = loggerRepository;
        }
        public void Log(string Description)
        {
            try
            {
                _loggerRepository.Log(new Logger { Type = 1, Date = DateTime.Now, Description = Description });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
