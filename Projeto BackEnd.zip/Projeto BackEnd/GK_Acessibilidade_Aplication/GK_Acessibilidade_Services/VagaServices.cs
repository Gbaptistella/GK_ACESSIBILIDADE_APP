﻿using GK_Acessibilidade_Data.Interfaces;
using GK_Acessibilidade_Domain.Entity.Segurança;
using GK_Acessibilidade_Domain.Entity.Vagas;
using GK_Acessibilidade_Services.Interfaces;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Services
{
    public class VagaServices : IVagaServices
    {
        private readonly IVagaRepository _vagaRepository;
        private readonly IEmpresaRepository _empresaRepository;
        public VagaServices(IVagaRepository vagaRepository, IEmpresaRepository empresaRepository)
        {
            _vagaRepository = vagaRepository;
            _empresaRepository = empresaRepository;
        }

        public IEnumerable<Vaga> ListVagas(string Codigo = "", string PalavraChave = "")
        {
            try
            {
                return _vagaRepository.ListVagas(Codigo, PalavraChave);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void AddVaga(Vaga vaga)
        {
            try
            {
                var empresa = _empresaRepository.GetEmpresas(vaga.CodigoEmpresa);

                if (empresa.ToList().Count == 0)
                    throw new Exception("Código da Empresa inválido, empresa inexistente!");
                else
                {
                    vaga.IDEMPRESA = empresa.FirstOrDefault().Id;
                    _vagaRepository.AddVaga(vaga);
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public void DeleteVaga(string Codigo)
        {
            try
            {
                _vagaRepository.DeleteVaga(Codigo);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }


}
