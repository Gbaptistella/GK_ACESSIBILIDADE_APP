﻿using GK_Acessibilidade_Data.Interfaces;
using GK_Acessibilidade_Domain.Entity.Empresas;
using GK_Acessibilidade_Domain.Entity.Vagas;
using GK_Acessibilidade_Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Services
{
    public class EmpresaServices : IEmpresaServices
    {
        private readonly IEmpresaRepository _empresaRepository;
        public EmpresaServices(IEmpresaRepository empresaRepository)
        {
            _empresaRepository = empresaRepository;
        }

        public IEnumerable<Empresa> GetEmpresas(string Codigo = "")
        {
            try
            {
                return _empresaRepository.GetEmpresas(Codigo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void AddEmpresa(Empresa empresa)
        {
            try
            {
                _empresaRepository.AddEmpresa(empresa);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void DeleteEmpresa(string Codigo)
        {
            try
            {
                _empresaRepository.DeleteEmpresa(Codigo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
