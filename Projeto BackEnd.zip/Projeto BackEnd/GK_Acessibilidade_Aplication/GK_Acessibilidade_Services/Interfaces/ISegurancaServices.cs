﻿using GK_Acessibilidade_Domain.Entity.Segurança;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Services.Interfaces
{
	public interface ISegurancaServices
	{
		string GenerateToken(string code, string pass);
	
	}
}
