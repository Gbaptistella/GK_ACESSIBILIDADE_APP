﻿using GK_Acessibilidade_Domain.Entity.Segurança;
using GK_Acessibilidade_Domain.Entity.Usuario;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Services.Interfaces
{
    public interface IUsuarioServices
    {
        IEnumerable<Login> GetAllUsers();
        Login GetUserById(string Code, string Pass);
        void AddUser(Login user);
        void UpdateUser(Login user);
        void DeleteUser(string Code);
        void AddComplementaresUser(DadosComplementaresUsuario User);
        IEnumerable<DadosComplementaresUsuario> GetCandidatos(string Code);
    }
}
