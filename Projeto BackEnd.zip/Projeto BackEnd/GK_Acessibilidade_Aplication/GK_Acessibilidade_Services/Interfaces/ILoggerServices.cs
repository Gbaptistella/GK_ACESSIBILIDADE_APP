﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Services.Interfaces
{
    public interface ILoggerServices
    {
       void Log(string Description);
    }
}
