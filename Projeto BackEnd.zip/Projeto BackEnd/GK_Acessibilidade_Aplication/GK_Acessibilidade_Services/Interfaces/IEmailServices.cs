﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Services.Interfaces
{
    public interface IEmailServices
    {
        void SendEmail(string toAddress, string subject, string body);
    }
}
