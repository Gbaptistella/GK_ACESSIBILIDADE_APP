﻿using GK_Acessibilidade_Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Services
{
    public class EmailServices : IEmailServices
    {
        public void SendEmail(string toAddress, string subject, string body)
        {
            // Set up the SMTP client
            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 465, // Adjust the port according to your provider's requirements
                Credentials = new NetworkCredential("gkacessibilidade@gmail.com", "123troca"),
                EnableSsl = true, // Enable SSL if required
            };

            // Create the email message
            MailMessage mailMessage = new MailMessage
            {
                From = new MailAddress("gkacessibilidade@gmail.com"),
                Subject = subject,
                Body = body,
                IsBodyHtml = true, // Set to true if the body contains HTML content
            };

            // Add the recipient
            mailMessage.To.Add(toAddress);

            try
            {
                // Send the email
                smtpClient.Send(mailMessage);
                Console.WriteLine("Email enviado com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Falha ao enviar o email: {ex.Message}");
            }
        }
    }
}
