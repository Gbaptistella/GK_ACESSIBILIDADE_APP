﻿using GK_Acessibilidade_Data.Interfaces;
using GK_Acessibilidade_Services.Interfaces;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace GK_Acessibilidade_Services
{
	public class SegurancaServices : ISegurancaServices
	{
		private const string SecretKey = "SECRETPASSINSIDEMYAPPLICATION12345"; // Ensure this key is at least 16 characters long
		private const string Issuer = "yourIssuer";
		private const string Audience = "yourAudience";
		private readonly ISegurancaRepository _segurancaRepository;
		public SegurancaServices(ISegurancaRepository segurancaRepository)
		{
			_segurancaRepository = segurancaRepository;
		}

		public string GenerateToken(string code, string pass)
		{
			var tokenExpiration = DateTime.UtcNow.AddHours(1);

			var claims = new[]
			{
			new Claim(JwtRegisteredClaimNames.Sub, code),
			new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
			new Claim(ClaimTypes.Role, "Admin")
		};

			var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(SecretKey));
			var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

			var token = new JwtSecurityToken(
				issuer: Issuer,
				audience: Audience,
				claims: claims,
				expires: tokenExpiration,
				signingCredentials: creds);

			var exists = _segurancaRepository.GetUserById(code, pass);
			if (exists != null)
				return new JwtSecurityTokenHandler().WriteToken(token);
			else
				return "";
		}
	}
}
