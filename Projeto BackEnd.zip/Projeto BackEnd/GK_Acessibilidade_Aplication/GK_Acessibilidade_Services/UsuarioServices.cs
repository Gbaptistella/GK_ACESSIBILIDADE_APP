﻿using GK_Acessibilidade_Data.Interfaces;
using GK_Acessibilidade_Domain.Entity.Segurança;
using GK_Acessibilidade_Domain.Entity.Usuario;
using GK_Acessibilidade_Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Services
{
    public class UsuarioServices : IUsuarioServices
    {
        private readonly IUsuarioRepository _usuarioRepository;
        public UsuarioServices(IUsuarioRepository usuarioRepository)
        {
            _usuarioRepository = usuarioRepository;
        }

        public Login GetUserById(string Code, string Pass)
        {
            return null;
        }

        public void AddUser(Login user)
        {
            _usuarioRepository.AddUser(user);
        }

        public void UpdateUser(Login user)
        {
            _usuarioRepository.UpdateUser(user);
        }

        public void DeleteUser(string Code)
        {
            _usuarioRepository.DeleteUser(Code);
        }
        public IEnumerable<Login> GetAllUsers()
        {
            return _usuarioRepository.GetAllUsers();
        }

        public void AddComplementaresUser(DadosComplementaresUsuario User)
        {
             _usuarioRepository.AddComplementaresUser(User);
        }

        public IEnumerable<DadosComplementaresUsuario> GetCandidatos(string Code)
        {
            return _usuarioRepository.GetCandidatos(Code);
        }

    }
}
