﻿using GK_Acessibilidade_Domain.Request.Usuario;
using GK_Acessibilidade_Domain.Entity.Segurança;
using GK_Acessibilidade_Domain.Entity.Usuario;
using GK_Acessibilidade_Domain.Request.Vaga;
using GK_Acessibilidade_Domain.Entity.Vagas;
using GK_Acessibilidade_Domain.Request.Empresa;
using GK_Acessibilidade_Domain.Entity.Empresas;

namespace GK_Acessibilidade_Aplication.Transform
{
    public class RequestTransform
    {

        public object Transform(int id, object request)
        {
            switch (id)
            {
                case (int)TransformEnum.CadastrarUsuarioRequest:
                    var CadastrarUsuario = (CadastrarUsuarioRequest)request;
                    return new Login { Code = CadastrarUsuario.Code, Email = CadastrarUsuario.Email, Pass = CadastrarUsuario.Pass, Date = DateTime.Now };
                case (int)TransformEnum.AlterarUsuarioRequest:
                    var AlterarUsuario = (AlterarUsuarioRequest)request;
                    return new Login { Code = AlterarUsuario.Code, Email = AlterarUsuario.Email, Pass = AlterarUsuario.Pass, Date = DateTime.Now };
                case (int)TransformEnum.DadosComplementaresUsuarioRequest:
                    var DadosComplementaresUsuario = (DadosComplementaresUsuarioRequest)request;
                    return new DadosComplementaresUsuario { Nome = DadosComplementaresUsuario.Nome, Sobrenome = DadosComplementaresUsuario.Sobrenome, DetalhesDeficiencia = DadosComplementaresUsuario.DetalhesDeficiencia, Idade = DadosComplementaresUsuario.Idade, Sexo = DadosComplementaresUsuario.Sexo, TipoDeficiencia = (int)DadosComplementaresUsuario.Deficiencia, Telefone = DadosComplementaresUsuario.Telefone, Email = DadosComplementaresUsuario.Email };
                case (int)TransformEnum.AddVagaRequest:
                    var AddVaga = (VagaRequest)request;
                    return new Vaga { Codigo = AddVaga.Codigo, Descricao = AddVaga.Descricao, Dt_Vaga = DateTime.Now, PreRequisitos = AddVaga.PreRequisitos, Salario = AddVaga.Salario, TipoContratacao = AddVaga.TipoContratacao, CodigoEmpresa = AddVaga.CodigoEmpresa };
                case (int)TransformEnum.AddEmpresaRequest:
                    var AddEmpresa = (EmpresaRequest)request;
                    return new Empresa { Codigo = AddEmpresa.Codigo, Cidade = AddEmpresa.Cidade, Endereco = AddEmpresa.Endereco, Ramo = AddEmpresa.Ramo, RazaoSocial = AddEmpresa.RazaoSocial, Telefone = AddEmpresa.Telefone };
                default:
                    return null;
            }


        }
    }



    public enum TransformEnum
    {
        CadastrarUsuarioRequest = 1,
        AlterarUsuarioRequest = 2,
        DadosComplementaresUsuarioRequest = 3,
        AddVagaRequest = 4,
        AddEmpresaRequest = 5
    }
}
