﻿using GK_Acessibilidade_Aplication.Transform;
using GK_Acessibilidade_Domain.Entity.Empresas;
using GK_Acessibilidade_Domain.Entity.Segurança;
using GK_Acessibilidade_Domain.Entity.Vagas;
using GK_Acessibilidade_Domain.Request.Empresa;
using GK_Acessibilidade_Domain.Request.Vaga;
using GK_Acessibilidade_Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GK_Acessibilidade_Aplication.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class EmpresaController : Controller
    {

        private readonly IEmpresaServices _empresaServices;

        public EmpresaController(IEmpresaServices empresaServices)
        {
            _empresaServices = empresaServices;
        }


        [HttpGet("Listar")]
        public IEnumerable<Empresa> Listar(string Codigo = "")
        {
            try
            {
                var ret = _empresaServices.GetEmpresas(Codigo);
                return ret;
            }
            catch (Exception ex)
            {
                return (IEnumerable<Empresa>)BadRequest(ex.Message);
            }
        }

        [HttpPost("Cadastrar")]
        public IActionResult Cadastrar(EmpresaRequest Request)
        {
            try
            {
                var ret = new RequestTransform().Transform((int)(TransformEnum.AddEmpresaRequest), Request);
                var request = (Empresa)ret;
                _empresaServices.AddEmpresa(request);
                return Ok("Empresa Cadastrada.");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("Excluir")]
        public IActionResult Excluir(string Codigo)
        {
            try
            {
                _empresaServices.DeleteEmpresa(Codigo);
                return Ok("Empresa Removida.");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }



    }
}
