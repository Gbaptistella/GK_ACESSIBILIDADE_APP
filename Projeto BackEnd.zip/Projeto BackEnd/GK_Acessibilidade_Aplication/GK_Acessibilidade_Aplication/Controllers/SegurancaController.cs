﻿using GK_Acessibilidade_Domain.Request.Seguranca;
using GK_Acessibilidade_Services;
using GK_Acessibilidade_Services.Interfaces;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

namespace GK_Acessibilidade_Aplication.Controllers
{
    [Route("api/[controller]")]
    public class SegurancaController : Controller
	{
		private readonly ISegurancaServices _segurancaServices;

		public SegurancaController(ISegurancaServices segurancaServices)
		{
			_segurancaServices = segurancaServices;
		}

		[HttpPost("Login")]
		public IActionResult Login(SegurancaRequest request)
		{
			try
			{
				var token = _segurancaServices.GenerateToken(request.Code, request.Pass);
				if (!String.IsNullOrEmpty(token))
					return Ok(new { Token = token });
				else
					return Unauthorized("Usuário e Senha inválidos.");
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}



	}
}