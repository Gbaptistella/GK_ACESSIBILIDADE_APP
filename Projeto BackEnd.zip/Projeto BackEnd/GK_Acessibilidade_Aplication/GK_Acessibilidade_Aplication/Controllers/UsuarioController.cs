using Azure.Core;
using GK_Acessibilidade_Aplication.Transform;
using GK_Acessibilidade_Domain.Entity.Seguran�a;
using GK_Acessibilidade_Domain.Entity.Usuario;
using GK_Acessibilidade_Domain.Request.Usuario;
using GK_Acessibilidade_Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GK_Acessibilidade_Aplication.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class UsuarioController : Controller
    {
        private readonly ILogger<UsuarioController> _logger;
        private readonly IUsuarioServices _usuarioServices;
        private readonly IEmailServices _emailServices;
        private readonly ILoggerServices _loggerServices;

        public UsuarioController(IUsuarioServices usuarioServices, ILogger<UsuarioController> logger, IEmailServices emailServices, ILoggerServices loggerServices)
        {
            _usuarioServices = usuarioServices;
            _logger = logger;
            _emailServices = emailServices;
            _loggerServices = loggerServices;
        }


        [HttpGet("Listar")]
        public IEnumerable<Login> Listar()
        {
            try
            {
                return _usuarioServices.GetAllUsers();
            }
            catch (Exception ex)
            {
                return (IEnumerable<Login>)BadRequest(ex.Message);
            }
        }

        [HttpPost("Cadastrar")]
        public IActionResult Cadastrar(CadastrarUsuarioRequest Request)
        {
            try
            {
                var ret = new RequestTransform().Transform((int)(TransformEnum.CadastrarUsuarioRequest), Request);
                var request = (Login)ret;
                _usuarioServices.AddUser(request);
                _emailServices.SendEmail(Request.Email, "GK Acessibilidade", "Bem vindo, Seu Cadastro foi finalizado, Credenciais: " + Request.Email + " - " + Request.Pass);
                _loggerServices.Log("Teste");
                return Ok("Usu�rio Cadastrado.");
            }
            catch (Exception ex)
            {
                _loggerServices.Log(ex.Message);
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("Atualizar")]
        public IActionResult Atualizar(AlterarUsuarioRequest Request)
        {
            try
            {
                var ret = new RequestTransform().Transform((int)(TransformEnum.AlterarUsuarioRequest), Request);
                var request = (Login)ret;
                _usuarioServices.UpdateUser(request);
                return Ok("Usu�rio Atualizado.");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("Excluir")]
        public IActionResult Excluir(string Code)
        {
            try
            {
                _usuarioServices.DeleteUser(Code);
                return Ok("Usu�rio exclu�do.");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpPost("DadosComplementares")]
        public IActionResult DadosComplementares(string Code, DadosComplementaresUsuarioRequest Request)
        {
            try
            {
                var ret = new RequestTransform().Transform((int)(TransformEnum.DadosComplementaresUsuarioRequest), Request);
                var request = (DadosComplementaresUsuario)ret;
                request.Code = Code;
                _usuarioServices.AddComplementaresUser(request);
                return Ok("Usu�rio Cadastrado.");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        [HttpGet("ListarCandidatos")]
        public IEnumerable<DadosComplementaresUsuario> ListarCandidatos(string Code = "")
        {
            try
            {
                return _usuarioServices.GetCandidatos(Code);
            }
            catch (Exception ex)
            {
                return (IEnumerable<DadosComplementaresUsuario>)BadRequest(ex.Message);
            }
        }



    }
}
