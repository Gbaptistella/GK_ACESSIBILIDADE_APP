﻿using GK_Acessibilidade_Aplication.Transform;
using GK_Acessibilidade_Domain.Entity.Segurança;
using GK_Acessibilidade_Domain.Entity.Usuario;
using GK_Acessibilidade_Domain.Entity.Vagas;
using GK_Acessibilidade_Domain.Request.Usuario;
using GK_Acessibilidade_Domain.Request.Vaga;
using GK_Acessibilidade_Services;
using GK_Acessibilidade_Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GK_Acessibilidade_Aplication.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class VagaController : Controller
    {
        private readonly IVagaServices _vagaServices;

        public VagaController(IVagaServices vagaServices)
        {
            _vagaServices = vagaServices;
        }


        [HttpGet("Listar")]
        public IEnumerable<Vaga> Listar(string Codigo = "", string PalavraChave = "")
        {
            try
            {
                return _vagaServices.ListVagas(Codigo,PalavraChave);
            }
            catch (Exception ex)
            {
                return (IEnumerable<Vaga>)BadRequest(ex.Message);
            }
        }

        [HttpPost("Cadastrar")]
        public IActionResult Cadastrar(VagaRequest Request)
        {
            try
            {
                var ret = new RequestTransform().Transform((int)(TransformEnum.AddVagaRequest), Request);
                var request = (Vaga)ret;
                _vagaServices.AddVaga(request);
                return Ok("Vaga Cadastrada.");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("Excluir")]
        public IActionResult Excluir(string Codigo)
        {
            try
            {
                _vagaServices.DeleteVaga(Codigo);
                return Ok("Vaga Removida.");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}
