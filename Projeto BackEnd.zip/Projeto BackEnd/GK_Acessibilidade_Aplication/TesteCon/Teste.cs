﻿using Microsoft.Data.SqlClient;

namespace TesteCon
{
	public class Teste
	{
		public void Connect()
		{
			SqlConnection Con = new SqlConnection(@"Data Source=localhost\MSSQLSERVER01;Initial Catalog=DB_ACESSECIBILIDADE;Persist Security Info=True;User ID=gbaptistella;Password=123troca;Trust Server Certificate=True");
			Con.Open();
			Con.Close();
		}

	}
}