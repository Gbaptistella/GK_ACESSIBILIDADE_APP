﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Domain.Request.Usuario
{
    public class DadosComplementaresUsuarioRequest
    {

        public string Nome { get; set; }
        public string Sobrenome { get; set; }
        public int Idade { get; set; }
        public string Sexo { get; set; }
        public TipoDeficiencia Deficiencia { get; set; }
        public string DetalhesDeficiencia { get; set; }
        public string Telefone { get; set; }
        public string Email { get; set; }
    }


    public enum TipoDeficiencia
    {
        Fisica = 1,
        Intelectual = 2,
        Sensorial = 3,
        Psicologica = 4
    }
}
