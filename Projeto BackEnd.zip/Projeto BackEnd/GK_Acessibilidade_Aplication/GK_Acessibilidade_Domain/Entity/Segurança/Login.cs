﻿using GK_Acessibilidade_Domain.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Domain.Entity.Segurança
{
    public class Login : BaseEntity
    {
        public int Id_Type { get; set; }
        public string Code { get; set; }
        public string Email { get; set; }
        public string Pass { get; set; }
        public DateTime Date { get; set; }
    }
}
