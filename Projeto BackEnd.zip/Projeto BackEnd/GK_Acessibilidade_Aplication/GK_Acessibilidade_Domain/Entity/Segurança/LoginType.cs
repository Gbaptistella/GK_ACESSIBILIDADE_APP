﻿using GK_Acessibilidade_Domain.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Domain.Entity.Segurança
{
    public class LoginType : BaseEntity
    {
        public string Code { get; set; }
    }
}
