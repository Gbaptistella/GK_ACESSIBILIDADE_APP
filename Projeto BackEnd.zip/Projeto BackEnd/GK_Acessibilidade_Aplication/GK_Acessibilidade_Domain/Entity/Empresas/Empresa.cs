﻿using GK_Acessibilidade_Domain.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Domain.Entity.Empresas
{
    public class Empresa : BaseEntity
    {
        public string Codigo { get; set; }
        public string RazaoSocial { get; set; }
        public string Ramo { get; set; }
        public string Cidade { get; set; }
        public string Endereco { get; set; }
        public string Telefone { get; set; }
    }
}
