﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Domain.Entity.Logger
{
    public class Logger
    {
        public int Type { get; set; }
        public string Description { get; set; }
        public DateTime Date { get; set; }
    }
}
