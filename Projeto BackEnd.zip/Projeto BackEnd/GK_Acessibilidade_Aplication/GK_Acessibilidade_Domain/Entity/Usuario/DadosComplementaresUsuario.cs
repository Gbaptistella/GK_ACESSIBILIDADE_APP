﻿using GK_Acessibilidade_Domain.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Domain.Entity.Usuario
{
    public class DadosComplementaresUsuario : BaseEntity
    {
        public string Nome { get; set; }
        public string Sobrenome { get; set; }
        public int Idade { get; set; }
        public string Sexo { get; set; }
        public int TipoDeficiencia { get; set; }
        public string DetalhesDeficiencia { get; set; }
        public string Telefone { get; set; }
        public string Code { get; set; }
        public string Email { get; set; }
    }
}
