﻿using GK_Acessibilidade_Domain.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Domain.Entity.Vagas
{
    public class Vaga : BaseEntity
    {
        public string Codigo { get; set; }
        public string Descricao { get; set; }
        public string PreRequisitos { get; set; }
        public int TipoContratacao { get; set; }
        public string Salario { get; set; }
        public DateTime Dt_Vaga { get; set; }
        public string CodigoEmpresa { get; set; }
        public int IDEMPRESA { get; set; }
    }
}