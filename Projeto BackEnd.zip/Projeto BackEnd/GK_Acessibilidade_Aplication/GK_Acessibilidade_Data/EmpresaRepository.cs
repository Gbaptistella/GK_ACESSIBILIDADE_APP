﻿using Dapper;
using GK_Acessibilidade_Data.Base;
using GK_Acessibilidade_Data.Interfaces;
using GK_Acessibilidade_Domain.Entity.Empresas;
using GK_Acessibilidade_Domain.Entity.Vagas;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Data
{
    public class EmpresaRepository: Repository, IEmpresaRepository
    {
        public IEnumerable<Empresa> GetEmpresas(string Codigo = "")
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                if (String.IsNullOrEmpty(Codigo))
                    return conn.Query<Empresa>("SELECT * FROM [EMPRESAS].[TB_EMPRESA]");
                else
                    return conn.Query<Empresa>("SELECT * FROM [EMPRESAS].[TB_EMPRESA] WHERE Codigo = @Codigo", new { Codigo = Codigo });

            }
        }
        public void AddEmpresa(Empresa empresa)
        {
            var exists = GetEmpresaByCode(empresa.Codigo);

            if (exists.ToList().Count >= 1)
                throw new Exception("Empresa já existente, insira outro Código!");

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                conn.Execute("INSERT INTO [EMPRESAS].[TB_EMPRESA] (Codigo, RazaoSocial, Ramo, Cidade, Endereco, Telefone) VALUES (@Codigo, @RazaoSocial, @Ramo, @Cidade, @Endereco, @Telefone)", empresa);
            }
        }

        public IEnumerable<Empresa> GetEmpresaByCode(string Codigo)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                return conn.Query<Empresa>("SELECT * FROM [EMPRESAS].[TB_EMPRESA] WHERE Codigo = @Codigo", new { Codigo = Codigo });
            }
        }

        public void DeleteEmpresa(string Codigo)
        {
            var exists = GetEmpresaByCode(Codigo);

            if (exists.ToList().Count == 0)
                throw new Exception("Empresa não encontrada, verifique seu código!");


            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                conn.Execute("DELETE [EMPRESAS].[TB_EMPRESA] WHERE Codigo = @Codigo", new { Codigo = Codigo });
            }
        }
    }
}
