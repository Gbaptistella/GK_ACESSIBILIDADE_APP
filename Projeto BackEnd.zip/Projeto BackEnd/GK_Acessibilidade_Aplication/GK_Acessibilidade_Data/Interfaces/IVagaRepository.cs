﻿using GK_Acessibilidade_Domain.Entity.Segurança;
using GK_Acessibilidade_Domain.Entity.Vagas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Data.Interfaces
{
    public interface IVagaRepository
    {
        IEnumerable<Vaga> ListVagas(string Codigo = "", string PalavraChave = "");
        void AddVaga(Vaga vaga);
        IEnumerable<Vaga> GetVagaByCode(string Codigo);
        void DeleteVaga(string Code);

    }
}
