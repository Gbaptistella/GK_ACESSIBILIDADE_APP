﻿using GK_Acessibilidade_Domain.Entity.Empresas;
using GK_Acessibilidade_Domain.Entity.Segurança;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Data.Interfaces
{
    public interface IEmpresaRepository
    {
        IEnumerable<Empresa> GetEmpresas(string Codigo = "");
        void AddEmpresa(Empresa empresa);
        IEnumerable<Empresa> GetEmpresaByCode(string Codigo);
        void DeleteEmpresa(string Code);
    }
}
