﻿using GK_Acessibilidade_Domain.Entity.Segurança;
using GK_Acessibilidade_Domain.Entity.Usuario;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Data.Interfaces
{
    public interface IUsuarioRepository
    {
        void AddUser(Login user);
        void UpdateUser(Login user);
        void DeleteUser(string Code);
        IEnumerable<Login> GetAllUsers();
        IEnumerable<Login> GetUserByCode(string Code);
        void AddComplementaresUser(DadosComplementaresUsuario user);
        IEnumerable<DadosComplementaresUsuario> GetCandidatos(string Code);
    }
}
