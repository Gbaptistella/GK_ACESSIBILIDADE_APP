﻿using Dapper;
using GK_Acessibilidade_Data.Base;
using GK_Acessibilidade_Data.Interfaces;
using GK_Acessibilidade_Domain.Entity.Logger;
using GK_Acessibilidade_Domain.Entity.Segurança;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Data
{
    public class LoggerRepository: Repository, ILoggerRepository
    {
        public void Log(Logger logger)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                conn.Execute("INSERT INTO [LOG].[LOGGING] (Type, Description, Date) VALUES (@Type, @Description, @Date)", logger);
            }
        }
    }
}
