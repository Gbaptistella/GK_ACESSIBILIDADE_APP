﻿using Dapper;
using GK_Acessibilidade_Data.Base;
using GK_Acessibilidade_Data.Interfaces;
using GK_Acessibilidade_Domain.Entity.Segurança;
using Microsoft.Data.SqlClient;

namespace GK_Acessibilidade_Data
{
    public class SegurancaRepository : Repository, ISegurancaRepository
	{
		public Login GetUserById(string Code, string Pass)
		{
			try
			{
				using (SqlConnection conn = new SqlConnection(_connectionString))
				{
					return conn.Query<Login>("SELECT * FROM SECURITY.TB_LOGIN WHERE Code = @Code and Pass = @Pass", new { Code, Pass }).FirstOrDefault();
				}
			}
			catch (SqlException ex)
			{
				throw ex;
			}
		}
	
	}
}
