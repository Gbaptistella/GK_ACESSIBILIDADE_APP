﻿using Dapper;
using GK_Acessibilidade_Data.Base;
using GK_Acessibilidade_Data.Interfaces;
using GK_Acessibilidade_Domain.Entity.Segurança;
using GK_Acessibilidade_Domain.Entity.Vagas;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Data
{
    public class VagaRepository : Repository, IVagaRepository
    {
        public IEnumerable<Vaga> ListVagas(string Codigo = "", string PalavraChave = "")
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                if (String.IsNullOrEmpty(Codigo) && String.IsNullOrEmpty(PalavraChave))
                    return conn.Query<Vaga>("SELECT * FROM VAGAS.TB_VAGA");
                else if (!String.IsNullOrEmpty(Codigo))
                    return conn.Query<Vaga>("SELECT * FROM VAGAS.TB_VAGA WHERE Codigo = @Codigo", new { Codigo = Codigo });
                else if (!String.IsNullOrEmpty(PalavraChave))
                    return conn.Query<Vaga>("SELECT * FROM VAGAS.TB_VAGA WHERE PreRequisitos  LIKE CONCAT('%',@PreRequisitos,'%')", new { PreRequisitos = PalavraChave });
                else
                    return conn.Query<Vaga>("SELECT * FROM VAGAS.TB_VAGA");
            }
        }
        public void AddVaga(Vaga vaga)
        {
            var exists = GetVagaByCode(vaga.Codigo);

            if (exists.ToList().Count >= 1)
                throw new Exception("Vaga já existente, insira outro Código!");

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                conn.Execute("INSERT INTO VAGAS.TB_VAGA (Codigo, Descricao, PreRequisitos, TipoContratacao, Salario, Dt_Vaga, IDEmpresa) VALUES (@Codigo, @Descricao, @PreRequisitos, @TipoContratacao, @Salario, GETDATE(), @IDEMPRESA)", vaga);
            }
        }

        public void DeleteVaga(string Codigo)
        {
            var exists = GetVagaByCode(Codigo);

            if (exists.ToList().Count == 0)
                throw new Exception("Vaga não encontrada, verifique seu código!");


            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                conn.Execute("DELETE VAGAS.TB_VAGA WHERE Codigo = @Codigo", new { Codigo = Codigo });
            }
        }



        public IEnumerable<Vaga> GetVagaByCode(string Codigo)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                return conn.Query<Vaga>("SELECT * FROM VAGAS.TB_VAGA WHERE Codigo = @Codigo", new { Codigo = Codigo });
            }
        }

    }
}