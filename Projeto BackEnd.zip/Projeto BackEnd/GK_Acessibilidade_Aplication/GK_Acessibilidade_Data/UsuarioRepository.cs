﻿using Dapper;
using GK_Acessibilidade_Data.Base;
using GK_Acessibilidade_Data.Interfaces;
using GK_Acessibilidade_Domain.Entity.Segurança;
using GK_Acessibilidade_Domain.Entity.Usuario;
using GK_Acessibilidade_Domain.Request.Usuario;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Data
{
    public class UsuarioRepository : Repository, IUsuarioRepository
    {
        public IEnumerable<Login> GetAllUsers()
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                return conn.Query<Login>("SELECT * FROM SECURITY.TB_LOGIN");
            }
        }

        public void AddUser(Login user)
        {
            var exists = GetUserByCode(user.Code);

            if (exists.ToList().Count >= 1)
                throw new Exception("Usuário já existente, insira outro Código!");

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                conn.Execute("INSERT INTO SECURITY.TB_LOGIN (Id_Type, Code, Email, Pass, Date) VALUES (2, @Code, @Email, @Pass, getdate())", user);
            }
        }

        public void UpdateUser(Login user)
        {
            var exists = GetUserByCode(user.Code);

            if (exists.ToList().Count == 0)
                throw new Exception("Usuário não encontrado, verifique seu código!");

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                conn.Execute("UPDATE SECURITY.TB_LOGIN SET Pass = @Pass, Email = @Email WHERE Code = @Code", user);
            }
        }

        public void DeleteUser(string Code)
        {
            var exists = GetUserByCode(Code);

            if (exists.ToList().Count == 0)
                throw new Exception("Usuário não encontrado, verifique seu código!");


            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                conn.Execute("DELETE SECURITY.TB_LOGIN WHERE Code = @Code", new { Code = Code });
            }
        }

        public IEnumerable<Login> GetUserByCode(string Code)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                return conn.Query<Login>("SELECT * FROM SECURITY.TB_LOGIN WHERE Code = @Code", new { Code = Code });
            }
        }

        public void AddComplementaresUser(DadosComplementaresUsuario user)
        {
            var exists = GetUserByCode(user.Code);

            if (exists.ToList().Count == 0)     
                throw new Exception("Usuário não encontrado, verifique seu código!");

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                conn.Execute("INSERT INTO [Usuario].[TB_USUARIO_DADOS_COMPLEMENTARES]  (Nome, Sobrenome, Sexo, TipoDeficiencia, DetalhesDeficiencia, Telefone, Code, Email) VALUES (@Nome, @Sobrenome, @Sexo, @TipoDeficiencia, @DetalhesDeficiencia, @Telefone, @Code, @Email)", user);
            }
        }

        public IEnumerable<DadosComplementaresUsuario> GetCandidatos(string Code)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                if (String.IsNullOrEmpty(Code))
                    return conn.Query<DadosComplementaresUsuario>("SELECT * FROM [Usuario].[TB_USUARIO_DADOS_COMPLEMENTARES]");
                else
                    return conn.Query<DadosComplementaresUsuario>("SELECT * FROM [Usuario].[TB_USUARIO_DADOS_COMPLEMENTARES] WHERE Code = @Code", new { Code = Code });

            }
        }


    }
}

