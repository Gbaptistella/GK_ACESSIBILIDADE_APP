﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK_Acessibilidade_Data.Base
{
	public class Repository
	{
		public string _connectionString  = @"Data Source=localhost\MSSQLSERVER01;Initial Catalog=DB_ACESSECIBILIDADE;Persist Security Info=True;User ID=gbaptistella;Password=123troca;Trust Server Certificate=True;";
	}
}
